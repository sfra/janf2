let DBConfig = {
    //   adapter:'mysql',
    config: '127.0.0.1',
    username: "szymom",
    password: "dupaWoloffa",
    database: "shops"

}
var privateData ={
    JANFPATH: "/home/szymon/sorsy/git/janf/janf"
}
exports.DBConfig = DBConfig;
exports.privateData = privateData;
