/*global require, process*/

'use strict';
let INIT_CONFIG = require(process.env.INIT_CONFIG);
let fs = require('fs'),
  ROOT_PATH = INIT_CONFIG.config.ROOT_PATH,
  libs = require(`${ROOT_PATH}/system/libfile`);



/**
 * @class Controller
 * @constructor
 * @param {Object} req request
 * @param {Object} res response
 * @param {String} contr controller name
 * @param {String} act action name
 * @param {Object} GET get parameters
 * @param {String} dane initial data
 * @param {String} mimetype
 */
class Controller {

  constructor(req, res, contr, act, GET, dane, mimetype) {
    console.log('From constructor');
    console.log(res);
    let ROOT_PATH = require(process.env.INIT_CONFIG).config.ROOT_PATH;

    this._Model = require(`${ROOT_PATH}/system/Model/Model`);
    this._View = require(`${ROOT_PATH}/system/View`);
    this._ModelSync = require(`${ROOT_PATH}/system/Model/ModelSync`);
    this.req = req;
    this.res = res;
    this.contr = contr;
    this._GET = {};
    this.dane = dane;
    console.log('res');
    console.log(res);

    if (act === undefined || act === '') {
      this.act = INIT_CONFIG.config.DEFAULT_ACTION; //"index"
    } else {
      this.act = act;
    }



    let i = 0;

    while (true) {
        if(typeof GET==='undefined') {break;}
        if (GET[i] === undefined) {break;}

      this._GET[GET[i]] = GET[i + 1];
      i += 1;
    }


    if (mimetype === undefined) {
      this.res.writeHead(200, {
        'Content-Type': 'text/html'
      });
    }
  }

  static get crypto() {
    return require('crypto');
  }
  static get libs() {
    require(ROOT_PATH + '/system/libfile');
  }
  static get moment() {
    require('moment');
  }

//   get req() {
//       return this.req;
//   }
//   set req(data) {
//     //this.req = data;
//     }
  
//     get res(){
//         return this.res;
//     }
//     set res(data){
//     //  this.res = data;
//   }

  



  /** methods **/
  /**
   * Caches the page according to the request url
   * @param{String} data
   */
  setCache(data) {

    let hash = Controller.crypto.createHash('sha1').update(this.req.url);

    fs.writeFile(`${ROOT_PATH}/application/cache/${hash.digest('hex')}`, data, function (err) {
      if (err) {
        console.log(err);
      } else {
        console.log('The page was cached!');
      }
    });

  }

  /**
   * retrieves the cache only if the cached file is not older than period
   * @param {Number} period time in miliseconds
   * returns {String}
   */
  getCache(period) {

    let hash = Controller.crypto.createHash('sha1').update(this.req.url);
    let out = false;
    let filepath = `${ROOT_PATH}/application/cache/${hash.digest('hex')}`;
    let dateOfMod;
    let dateNow = require('moment').utc().valueOf();

    try {

      dateOfMod = require('moment').utc(fs.statSync(filepath).mtime).valueOf();


      if (dateNow - dateOfMod < period) {
        out = this.libs.toString(filepath);
      }

      return out;

    } catch (e) {
      console.log(e);
      return out;
    }



  }

  /**
   * gets the content of the page written in the file with chtml extension, located in application/contents folder
   * @param {String} a name if the file. If is undefined then the name controllerName.actionName.chtml is used
   * @returns {String} Content of the file
   */
  getContent(file) {

    if (file === undefined) {
      return libs.toString(`${ROOT_PATH}/application/contents/${this.contr}.${this.act}.chtml`);
    
    }
    return libs.toString(`${ROOT_PATH}/application/contents${file}`);
  }





}








exports.Controller = Controller;
//exports.Controller.prototype = Controller.prototype;
